/**
 * viewportManager
 *
 * FIX: this file was missing entirely from src/services/, while
 * src/App.tsx still imported it ("Cannot find module
 * './services/viewportManager'"). That unresolved import made
 * `vite build` fail immediately, which is why the GitHub Actions
 * "Build web application" step kept failing before Gradle/Android
 * ever ran.
 *
 * Purpose: keep a small compatibility variable for legacy components.
 * The application root itself uses CSS 100dvh now. We deliberately do
 * NOT resize the entire app from VisualViewport scroll/resize events:
 * doing that during Android startup can cause the one-frame "stretch /
 * snap back" effect and can move fixed UI underneath system bars.
 *
 * Usage (already wired up in App.tsx):
 *   const cleanup = viewportManager.init();
 *   // ... later, on unmount:
 *   cleanup();
 *
 * In CSS, use it like:
 *   .full-height { height: var(--app-height, 100vh); }
 */

function setAppHeightVar() {
  if (typeof window === 'undefined') return;

  // CSS 100dvh is responsible for the real app layout. Keep this variable
  // only for legacy consumers and use the stable layout viewport height so
  // browser/keyboard animation cannot stretch the whole application.
  const height = window.innerHeight || 0;
  if (height > 0) {
    document.documentElement.style.setProperty('--app-height', `${height}px`);
  }
}

function init(): () => void {
  if (typeof window === 'undefined') {
    // no-op on non-browser environments (SSR/build-time), keeps this
    // safe to import anywhere.
    return () => {};
  }

  setAppHeightVar();

  const handleResize = () => setAppHeightVar();

  window.addEventListener('resize', handleResize);
  window.addEventListener('orientationchange', handleResize);

  if (window.visualViewport) {
    // Resize is retained for compatibility, but scrolling the visual
    // viewport must never resize the entire application.
    window.visualViewport.addEventListener('resize', handleResize);
  }

  return () => {
    window.removeEventListener('resize', handleResize);
    window.removeEventListener('orientationchange', handleResize);
    if (window.visualViewport) {
      window.visualViewport.removeEventListener('resize', handleResize);
    }
  };
}

export const viewportManager = {
  init,
};
